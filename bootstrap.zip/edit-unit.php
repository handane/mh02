<?php
session_start();
include("database/db.php");
$deviceid = $_GET['deviceid'];
if (!isset($_SESSION["admin"])) {
  echo "<script>location='login.php'</script>";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include('./include/meta.php') ?>
  
  <style>
    #ftz16 {
      font-size: 16px;
    }

    body {
      background-color: #f1f1f1;
    }
  </style>
</head>

<body class="sb-nav-fixed">
  <?php include('./include/nav.php') ?>
  
  <div id="layoutSidenav">
    <?php include('./include/sidenav.php') ?>
    
    <div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-3">
          <ol class="breadcrumb mb-4 mt-2">
            <li class=""><a href="./"><< back</a> | </li>
            <li class="">| <b>Detail Device</b></li>
          </ol>
            <div class="card mt-3 col-md-6">
                <div class="card-body">
                  <?php 
                  $get_device = mysqli_query($conn, "SELECT * FROM devices WHERE deviceid = '$deviceid'");
                  $row = mysqli_fetch_array($get_device);
                  ?>
                    <form class="row g-3" method="POST" enctype="multipart/form-data">
                    <div class="">
                    <label for="" class="form-label-md"><b>Device ID</b></label>
                    <input type="text" class="form-control" value="<?= $row['deviceid'] ?>"  name="unit_number" readonly>

                    <label for="" class="form-label-md mt-2"><b>Unit Number</b></label>
                    <input type="text" class="form-control" value="<?= $row['unitno'] ?>"  name="unit_number" readonly>

                    <label for="" class="form-label-md mt-2"><b>Device IP</b></label>
                    <input type="text" class="form-control" value="<?= $row['deviceip'] ?>"  name="unit_number" readonly>

                    <label for="" class="form-label-md mt-2"><b>Status</b></label>
                    <input type="text" class="form-control" value="<?= $row['mh02status'] ?>"  name="unit_number" readonly>

                    <?php 
                    if ($row['mh02status'] != 'terpasang') { 
                    ?>
                    <label for="" class="form-label-md mt-3"><b>Update Status</b></label>
                    <select name="status" class="form-select" id="" require>
                        <option value="<?= $row['mh02status'] ?>"></option>
                        <option value="rusak">Rusak</option>
                        <option value="standby">Standby</option>
                        <option value="kembali ke HO">Kembali ke HO</option>
                    </select>
                    <?php } ?>

                    <label for="" class="form-label-md mt-2"><b><i>*Note</b></i></label>
                    <textarea name="note" class="form-control" id="" value="<?= $row['note'] ?>"> <?= $row['note'] ?></textarea>
                    
                      <div class="mt-3">
                        <input type="submit" class="btn btn-success col-md-4" name="submit" value="Update" />

                        <a class="btn btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus data, ini akan hilang selamanya?')" href="delete.php?deviceid=<?= $deviceid ?>">Delete Device</a>
                      </div>
                    </div>
                    </form>

                <?php
                    if (isset($_POST['submit'])) {
                    date_default_timezone_set('Asia/Makassar');
                    $status = $_POST['status'];
                    $note = $_POST['note'];
                    $date = date('d-m-Y');

                    $update = mysqli_query($conn, "UPDATE devices SET
                        deviceid = '$deviceid',
                        mh02status = '$status',
                        last_update = '$date',
                        note = '$note'
                        WHERE deviceid = '$deviceid'
                        ");
                    if ($update) {
                      echo "<script>
                      alert('Data berhasil diupdate');
                      window.location='edit-unit.php?deviceid=" . $deviceid . "';
                      </script>";
                  
                    } else {
                    echo 'gagal ' . mysqli_error($conn);
                    }
                    }
                ?>
                </div>
            </div>
        </div>
    </main>
    <footer class="mt-5">
    </footer>
    </div>
  </div>
  <script src="js/scripts.js"></script>
  <script src="datatables/datatable.js"></script>
  <script src="js/datatables-simple-demo.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>


</body>

</html>