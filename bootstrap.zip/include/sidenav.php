<div id="layoutSidenav_nav">
         <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
               <div class="nav">
                  <div class="sb-sidenav-menu-heading">Menu</div>
                  <a class="nav-link" href="index.php">
                     <div class="sb-nav-link-icon">
                        <i class="far fa-file-alt"></i>
                     </div>
                     Device
                  </a>
                  <a class="nav-link" href="tambah-unit.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-edit"></i>
                     </div>
                     Tambah Device
                  </a>
                  <a class="nav-link" href="pasang-baru.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-edit"></i>
                     </div>
                     Pasang Baru
                  </a>
                  <a class="nav-link" href="replace-unit.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-edit"></i>
                     </div>
                     Replace
                  </a>
                  <a class="nav-link" href="lepas-unit.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-cut"></i>
                     </div>
                     Lepas/Copot
                  </a>
                  <!-- <a class="nav-link" href="data-beli.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-chart-line"></i>
                     </div>
                     Income
                  </a>
                  <a class="nav-link" href="pembelian.php">
                     <div class="sb-nav-link-icon">
                        <i class="far fa-file-alt"></i>
                     </div>
                     Pengerjaan
                  </a>
                  <a class="nav-link" href="latihan.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-edit"></i>
                     </div>
                     Latihan
                  </a> -->
                  <a class="nav-link" href="logout.php">
                     <div class="sb-nav-link-icon">
                        <i class="fas fa-sign-out-alt"></i>
                     </div>
                     Logout
                  </a>
               </div>
            </div>
         </nav>
      </div>